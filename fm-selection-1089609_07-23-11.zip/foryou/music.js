var o = document.getElementById("myOpening"); 
    
function playOpening() { 
  o.play(); 
} 

function pauseOpening() { 
  o.pause(); 
} 

var x = document.getElementById("myAudio"); 
    
function playAudio() { 
  x.play(); 
} 

function pauseAudio() { 
  x.pause(); 
} 

$(document).ready(function () {
    $('i').click(function () {
      $(this).hide("slow", "");
      $('img').show();
    });
    $('img').click(function () {
      $('span').show();
      $(this).hide();
    });
  });